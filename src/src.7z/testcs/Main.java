package testcs;

import a.db.create.BuildDB;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test.testCs();
		//Test.delete();
		
		//Test2.TestCSFailures();
		
		System.out.println("done");
		//BuildDB.createDb();
	}

}
