package core.facade;

/**
 * for login return type
 * @author Itsik
 *
 */
public interface ClientFacade {
	
	

}
