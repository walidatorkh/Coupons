package core.cs;

/**
 * client types:
 * ADMIN, COMPANY, CUSTOMER
 * @author Itsik
 *
 */
public enum ClientType {
	ADMIN, COMPANY, CUSTOMER;
}
