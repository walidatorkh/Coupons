package core.beans;

/**
 * 
 * coupon types:
 * 
 * RESTAURANTS, 
	ELECTRICITY, 
	FOOD, 
	HEALTH,
    SPORTS, 
    CAMPING, 
    TRAVELING 
 * @author Itsik
 *
 */
public enum CouponType {
	RESTAURANTS, 
	ELECTRICITY, 
	FOOD, 
	HEALTH,
    SPORTS, 
    CAMPING, 
    TRAVELING 

}
